class Box {
  constructor(x, y){
    this.x;
    this.y;
  }

  fall(){

  }

  show(){
    stroke(138, 43, 226);
    line(x,y,x,y+10)
  }
}
