rains = []

function setup() {
  createCanvas(windowWidth, windowHeight);

  for (var i = 0; i < 1100; i++){
    rains[i] = new Rain();
  }
}

function draw() {
  background(0);

  for (var i = 0; i < rains.length; i++){
    rains[i].fall();
    rains[i].show();
  }



}
