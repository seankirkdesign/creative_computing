class Rain {
  constructor(x, y, yspeed){
    this.x = random(width);
    this.y = random(-height);
    this.yspeed = random(-2,15);
  }

  fall(){
    this.y += this.yspeed;

    if (this.y > height){
      this.y = random(-height);
    }
  }

  show(){
    stroke(255);
    // text('look', this.x, this. y);
    strokeWeight(5);
    line(this.x, this.y, this.x, this.y + 10)
  }
}
