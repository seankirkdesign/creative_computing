# Coding Challenge 86: Cube Wave by Bees and Bombs
- [Edited Video](https://www.youtube.com/watch?v=H81Tdrmz2LA)
- [Example Running Online](https://codingtrain.github.io/Rainbow-Code/CodingChallenges/CC_086_beesandbombs/)

## Community Editions
* Add your version here
* Lugsole's contribution [Source Code](https://github.com/Lugsole/Cube_Wave)
* stellartux's contribution [Source Code](https://github.com/stellartux/CC86) |  [Live Demo](http://stellartux.github.io/CC86)
* Davenewt's colour-cycling contribution [Demo on Codepen](https://codepen.io/anon/pen/wprwdP?editors=0010)

* Gareth Williams (Gaweph) - Rainbow Colours (static and Flowing) - [Source Code](https://github.com/Gaweph/CodingTrain-RainbowCode-Challenges/tree/master/CC_086_beesandbombs) | [Live Demo](https://gaweph.github.io/CodingTrain-RainbowCode-Challenges/CC_086_beesandbombs/)
