// Daniel Shiffman
// http://codingtra.in
// http://patreon.com/codingtrain

// Video: https://youtu.be/H81Tdrmz2LA

// Original GIF: https://beesandbombs.tumblr.com/post/149654056864/cube-wave

let angle = 0;
let w = 60;
let ma;
let maxD;

function setup() {
  createCanvas(1000, 1000, WEBGL);
  ma = atan(cos(QUARTER_PI));
  maxD = dist(0, 0, 200, 200);
}

function draw() {
  background(230);

  r = map(mouseX, 0, windowWidth, 0, 255);
  g = map(mouseY, 0, windowHeight, 0, 255);

  var dirX = (mouseX / width - 0.5) * 2;
  var dirY = (mouseY / height - 0.5) * 2;
  directionalLight(mouseX, mouseY, 250, -dirX, -dirY, 1);
  ambientMaterial(mouseX, mouseY, 250);

  ortho(-800, 800, 800, -800, 0, 2000);
  rotateX(-ma);
  rotateY(-QUARTER_PI)﻿

  for (let z = 0; z < height; z += w) {
    for (let x = 0; x < width; x += w) {
      push();
      let d = dist(x, z, width / 2, height / 2);
      let offset = map(d, 0, maxD, -PI, PI);
      let a = angle + offset;
      let h = floor(map(sin(a), -1, 1, 100, 300));

      translate(x - width / 2, 0, z - height / 2);
      // normalMaterial();
      box(w, h, w);
      //rect(x - width / 2 + w / 2, 0, w - 2, h);
      pop();
    }
  }

  angle -= 0.07;
}
